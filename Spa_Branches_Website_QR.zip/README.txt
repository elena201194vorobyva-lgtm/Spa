HOW TO USE

1. Upload index.html to any hosting:
   - your website hosting
   - Netlify
   - GitHub Pages
   - Wix / Tilda custom HTML block
   - or ask your web developer to place it on a page

2. After you get the real public link, create a new QR code for that exact link.
   Current placeholder used in the included QR:
   https://your-domain.com/spa-branches/

3. Promo code displayed on the page:
   SPA10

4. You can change promo code inside index.html by replacing:
   SPA10
